
from django.db import models

class Person(models.Model):
    name = models.CharField(max_length=50)
    description = models.CharField(max_length=300, default='')
    quantity = models.CharField(max_length=300, null=True)
    price = models.IntegerField()
    images = models.ImageField(upload_to='images/', null=True)

    def __str__(self):
        return self.name

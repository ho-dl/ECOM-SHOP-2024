from audioop import reverse
from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render

from APP.models import Person

# Create your views here.


def index(request):
    address =Person.objects.all()
    return render(request,'index.html',{'address':address})

def dashboard(request):
    dashboard_address =Person.objects.all()
    return render(request,'dashboard.html',{'dashboard_address':dashboard_address})



def edit_person(request, person_id):
    person = get_object_or_404(Person, pk=person_id)
    if request.method == 'POST':
        person.name = request.POST.get('name')
        person.description = request.POST.get('description')
        person.price = request.POST.get('price')
        person.quantity = request.POST.get('quantity')
        person.images=request.POST.get('images')
        person.save()
        return redirect('dashboard')  # Redirect back to the dashboard after editing
    return render(request, 'eddit.html', {'person': person})


def delete_person(request, person_id):
    person = get_object_or_404(Person, pk=person_id)  # Use Person instead of person
    person.delete()
    return redirect('dashboard')

def upload_content(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        description = request.POST.get('address')
        price = request.POST.get('price')

        quantity = request.POST.get('quantity')
        image = request.FILES.get('image')

        person = Person.objects.create(
            name=name,
            description=description,
            price=price,
            quantity=quantity,
            images=image
        )

        return redirect('dashboard')  # Redirect to a success page
    else:
        return render(request, 'upload.html')
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('dashboard/',views.dashboard,name='dashboard'),
    path('edit/<int:person_id>/', views.edit_person, name='edit_person'),
    path('delete/<int:person_id>/',views.delete_person,name='delete_person'),
    path('upload_content/', views.upload_content, name='upload_content'),
    
]
